<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php _e( 'Booking is already confirmed.', 'motopress-hotel-booking' ); ?>
</p>