<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class = "mphb-required-fields-tip">
	<small>
		<?php _e( 'Required fields are followed by', 'motopress-hotel-booking' ); ?>
		<abbr title="required">*</abbr>
	</small>
</p>