<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="mphb-not-found">
	<?php _e( 'No rooms matched criteria.', 'motopress-hotel-booking' ); ?>
</p>