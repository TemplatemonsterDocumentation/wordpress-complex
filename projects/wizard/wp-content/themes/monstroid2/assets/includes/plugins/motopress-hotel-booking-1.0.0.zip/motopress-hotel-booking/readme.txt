=== Hotel Booking ===
Contributors: MotoPress
Donate link: http://www.getmotopress.com/
Tags: hotel, booking, reservation
Requires at least: 4.5
Tested up to: 4.7
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Manage your hotel booking services.

== Description ==

Manage your hotel booking services.

== Installation ==

1. Upload the MotoPress plugin to the /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Screenshots ==


== Changelog ==

= 1.0.0 =

* Initial release