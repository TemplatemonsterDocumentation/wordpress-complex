<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

_e( 'No rooms found.', 'motopress-hotel-booking' );