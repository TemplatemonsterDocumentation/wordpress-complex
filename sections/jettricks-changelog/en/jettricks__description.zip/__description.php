<h3>Changelog</h3>

<h5>In this block you can view the latest updates for JetTricks plugin.
 </h5>



 <h4>Version 1.1.0 (July 4, 2018)</h4>

<ul class="marked-list">
<li>Added 3 new effects: Satellite Element, Section Particles and Tooltip;</li>
<li>Improved compatibility with Elementor v.2.1.</li>
</ul>
